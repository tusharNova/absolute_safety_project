<?php
echo "<h2>add client  with AJAX method..</h2>";
echo "code";
